#!/usr/bin/env python3
"""
ProtonDrive Linux Client - Main entry point
"""

from . import main

if __name__ == "__main__":
    main()